﻿//Author:   Gregorics Tibor
//Date:     2021.11.16.
//Title:    class of pumps of petrolstations

using System.Collections.Generic;
using System.Threading;

namespace PetrolStation
{
    class Pump
    {
        public int Quantity { get; private set; }
        public void ResetQuantity() { Quantity = 0; }

        private readonly Queue<Car> queue = new ();
        public Pump() { ResetQuantity(); }

        private readonly object criticalSection = new ();

        public bool IsFirst(Car car) 
        {
            Monitor.Enter(criticalSection); 
            bool l = queue.Count > 0 && queue.Peek() == car;
            Monitor.Exit(criticalSection);
            return l;
        }

        public void JoinQueue(Car car)
        {
            Monitor.Enter(criticalSection);
            queue.Enqueue(car);   // joins the queue
            while (!IsFirst(car)) Monitor.Wait(criticalSection);   // wait until he is the first
            Monitor.Exit(criticalSection);
        }

        public void Fill(Car car, int liter)
        {
            Monitor.Enter(criticalSection); 
            if (!IsFirst(car)) return;
            Quantity = liter;
            Monitor.Exit(criticalSection);
            Thread.Sleep(liter * 200); // time of fueling depends on the amount of petrol fueled
        }
        public void Leave(Car car)
        {
            Monitor.Enter(criticalSection);
            if (IsFirst(car) && 0 == Quantity) queue.Dequeue();  // leaves the queue
            Monitor.PulseAll(criticalSection);
            Monitor.Exit(criticalSection);
        }
    }
}
