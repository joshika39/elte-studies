﻿//Author:   Gregorics Tibor
//Date:     2021.11.16.
//Title:    class of petrolstations

using System.Collections.Generic;

namespace PetrolStation
{
    class PetrolStation
    {
        private readonly List<Pump> pumps = new ();

        public Cash CashDesk { get; }
        public int Unit { get; set; }

        public PetrolStation(int n, int m)
        {
            for (int i = 0; i < n; ++i)
            {
                pumps.Add(new Pump());
            }
            CashDesk = new Cash(this, m);
        }

        public Pump GetPump( int number) { return pumps[number]; }
        public int PumpsCount { get => pumps.Count; }
    }
}
