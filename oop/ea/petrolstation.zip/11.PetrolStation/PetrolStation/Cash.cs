﻿//Author:   Gregorics Tibor
//Date:     2021.11.16.
//Title:    class of cash desks

using System.Collections.Generic;
using System.Threading;

namespace PetrolStation
{
    class Cash
    {
        private readonly PetrolStation station;
        private readonly int capacity;

        public Cash(PetrolStation station, int m) { this.station = station; capacity = m; }

        private int engaged;    
        private readonly Queue<Car> queue = new ();

        private static int Invoice(int liter, int price) { return liter * price; }
        private bool Search(Car car, out int i)
        {
            for (i = 0; i < station.PumpsCount; ++i)
            {
                if (station.GetPump(i).IsFirst(car)) return true;
            }
            return false;
        }

        private readonly object criticalSection = new ();
        public void JoinQueue(Car car)
        {
            Monitor.Enter(criticalSection);
            queue.Enqueue(car);   // joins the queue
            while ( !(queue.Count > 0 && queue.Peek() == car) || engaged == capacity) Monitor.Wait(criticalSection);
            Monitor.Exit(criticalSection);
        }
        public int Pay(Car car)
        {
            Monitor.Enter(criticalSection); 
            ++engaged;              // steps to a cash desk
            queue.Dequeue();        // leaves the queue
            Monitor.Exit(criticalSection);

            if (!Search(car, out int number)) return 0;
            int sum = Invoice( station.GetPump(number).Quantity, station.Unit );
            station.GetPump(number).ResetQuantity();   // resets the display of the i-th pump
            Thread.Sleep(1000);     //elapsed time of paying

            Monitor.Enter(criticalSection);
            --engaged;              // leaves the cash desk
            Monitor.PulseAll(criticalSection);
            Monitor.Exit(criticalSection);

            return sum;
        }
    }
}
