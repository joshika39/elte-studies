module Homework7 where

import Data.List

mapping :: [(Char, Char)]
mapping = [('0', '3'), ('1', '4'), ('2', '5'), ('3', '6'),
           ('4', '7'), ('5', '8'), ('6', '9'), ('7', 'A'),
           ('8', 'B'), ('9', 'C'), ('A', 'D'), ('B', 'E'),
           ('C', 'F'), ('D', 'G'), ('E', 'H'), ('F', 'I'),
           ('G', 'J'), ('H', 'K'), ('I', 'L'), ('J', 'M'),
           ('K', 'N'), ('L', 'O'), ('M', 'P'), ('N', 'Q'),
           ('O', 'R'), ('P', 'S'), ('Q', 'T'), ('R', 'U'),
           ('S', 'V'), ('T', 'W'), ('U', 'X'), ('V', 'Y'),
           ('W', 'Z'), ('X', 'A'), ('Y', 'B'), ('Z', 'c'),
           ('a', 'd'), ('b', 'e'), ('c', 'f'), ('d', 'g'),
           ('e', 'h'), ('f', 'i'), ('g', 'j'), ('h', 'k'),
           ('i', 'l'), ('j', 'm'), ('k', 'n'), ('l', 'o'),
           ('m', 'p'), ('n', 'q'), ('o', 'r'), ('p', 's'),
           ('q', 't'), ('r', 'u'), ('s', 'v'), ('t', 'w'),
           ('u', 'x'), ('v', 'y'), ('w', 'z'), ('x', 'a'),
           ('y', 'b'), ('z', 'c')]

encodeCaesar :: String -> String
encodeCaesar l = map (\(x:xs) -> getNewChar x) (group l)
    where
        getNewChar :: Char -> Char
        getNewChar c = snd (head (filter (\(x,y) -> x == c) mapping))

decodeCaesar :: String -> String
decodeCaesar l = map (\(x:xs) -> getNewChar x) (group l)
    where
        getNewChar :: Char -> Char
        getNewChar c = fst (head (filter (\(x,y) -> y == c) mapping))