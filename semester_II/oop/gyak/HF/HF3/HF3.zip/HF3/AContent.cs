﻿namespace HF3
{
    public abstract class AContent : IContent
    {
        public abstract int GetSize();
    }
}
