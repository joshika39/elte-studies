﻿// See https://aka.ms/new-console-template for more information


using HF3;
var root = new Dir();
var file1 = new OwnFile(3);
var file2 = new OwnFile(1);
var file3 = new OwnFile(6);
var gameDir = new Dir();
gameDir.Content.Add(new OwnFile(12));
gameDir.Content.Add(new OwnFile(67));

root.Content.Add(new OwnFile(4));
root.Content.Add(gameDir);
root.Content.Add(file1);
root.Content.Add(file2);
root.Content.Add(file3);

Console.WriteLine(root.GetSize());