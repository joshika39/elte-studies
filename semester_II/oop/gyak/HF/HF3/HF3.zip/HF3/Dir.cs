﻿namespace HF3
{
    public class Dir : AContent
    {
        public IList<IContent> Content { get; set; }
        public Dir()
        {
            Content = new List<IContent>();
        }

        public override int GetSize()
        {
            var sum = 0;
            foreach (var content in Content)
            {
                sum += content.GetSize();
            }
            return sum;
        }

    }
}
