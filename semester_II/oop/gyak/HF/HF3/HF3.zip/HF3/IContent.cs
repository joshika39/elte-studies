﻿namespace HF3
{
    public interface IContent
    {
        int GetSize();
    }
}
