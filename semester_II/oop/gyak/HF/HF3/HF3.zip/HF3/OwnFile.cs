﻿namespace HF3
{
    public class OwnFile : AContent
    {
        private readonly int _size;
        public OwnFile(int size)
        {
            _size = size;
        }
        public override int GetSize()
        {
            return _size;
        }
    }
}
