﻿//Author:   Gregorics Tibor
//Date:     2021.11.03.
//Title:    Selection of high-heart rate athletes

using System;
using TextFile;

namespace CountMin
{
    class InpFile
    {
        public struct Measurement 
        { 
            public string time; 
            public int pulse; 
        }

        private readonly TextFileReader reader;
        public InpFile(string fname)
        { 
            reader = new TextFileReader(fname); 
        }
        public bool Read(out Measurement dx)
        {
            reader.ReadString(out dx.time);
            return reader.ReadInt(out dx.pulse);
        }
    }
    class Program
    {
        static void Main()
        {
            try
            {
                InpFile x = new ("input.txt");
                InpFile.Measurement e;

                int c = 0;
                while (x.Read(out e) && e.pulse < 100) ++c;

                x.Read(out e);
                int min = e.pulse;
                while (x.Read(out e))
                {
                    if (e.pulse < min) min = e.pulse;
                }
                Console.WriteLine($"count: {c}, min: {min}");

            } 
            catch(System.IO.FileNotFoundException)
            {
                Console.WriteLine("Could not open the textfile");
            }
        }

    }
}
