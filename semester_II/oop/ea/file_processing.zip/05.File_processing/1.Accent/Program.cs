﻿//Author:   Gregorics Tibor
//Date:     2021.11.03.
//Title:    Changing accented letters

using System.IO;
using TextFile;

namespace Accent {

    class Accent
    {
        static void Main()
        {
            string inputfilename = "inp.txt";
            TextFileReader reader = new (inputfilename);

            string outputfilename = @"..\..\..\out.txt";
            using StreamWriter writer = new(outputfilename);
            // Copying with a bit change
            while (reader.ReadChar(out char ch))
            {
                writer.Write(Transform(ch));
            }
        }

       static char Transform(char ch)
        {
            char new_ch;
            switch (ch)
            {
                case 'á': new_ch = 'a'; break;
                case 'é': new_ch = 'e'; break;
                case 'í': new_ch = 'i'; break;
                case 'ó': case 'ö': case 'ő': new_ch = 'o'; break;
                case 'ú': case 'ü': case 'ű': new_ch = 'u'; break;
                case 'Á': new_ch = 'A'; break;
                case 'É': new_ch = 'E'; break;
                case 'Í': new_ch = 'I'; break;
                case 'Ó': case 'Ö': case 'Ő': new_ch = 'O'; break;
                case 'Ú': case 'Ü': case 'Ű': new_ch = 'U'; break;
                default: new_ch = ch; break;
            }
            return new_ch;
        }

    }

}
