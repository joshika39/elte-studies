﻿//Author:   Gregorics Tibor
//Date:     2021.11.03.
//Title:    Selection of healthy athletes

using System;

namespace Healthy
{
    class Program
    {
        static void Main()
        {
            try
            {
                InFile x = new ("input.txt");
                while (x.Read(out InFile.Athlete e))
                {
                    if (e.below)
                    {
                        Console.WriteLine(e.name);
                    }
                }
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Could not open the textfile");
            }
            catch (InFile.EmptyRowException)
            {
                Console.WriteLine("Could not open the textfile");
            }
        }


    }
}
