﻿//Author:   Gregorics Tibor
//Date:     2021.11.03.
//Title:    Selection of high-heart rate athletes

using System;
using TextFile;

using System.IO;

namespace Selection
{
    class Program
    {
        class InpFile
        {
            public struct Measurement { public string time; public int pulse; }
            private readonly TextFileReader reader;
            public InpFile(string fname)
            { reader = new TextFileReader(fname); }
            public bool Read(out Measurement dx)
            {
                reader.ReadString(out dx.time);
                return reader.ReadInt(out dx.pulse);
            }
        }

        static void Main()
        {
            try
            {
                InpFile x = new ("input.txt");
                Console.WriteLine("Selected measurements:");
                int max = 0;
                bool low = false;
                while (x.Read(out InpFile.Measurement e))
                {
                    if (e.pulse >= 100)
                    {
                        Console.WriteLine($"time: {e.time}, pulse: {e.pulse}");
                    }
                    if (e.pulse > max) max = e.pulse;
                    low = low || e.pulse < 60;
                }
                string ans = low ? "" : "not ";
                Console.WriteLine($"maxima: {max}, there is {ans}a low pulse");
                }
            catch (System.IO.FileNotFoundException) 
            { 
                Console.WriteLine("Could not open the textfile"); 
            }
        }

    }
}
