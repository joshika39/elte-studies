﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of sensors

using System;
using System.Threading;

namespace Garagegate
{
    class Sensor : StateMachine<Signal>
    {
        public readonly Garagegate system;
        enum SensorState { active, passive };
        private SensorState currentState;
        public string CurrentState
        {
            get { return currentState.ToString(); }
        }       public Sensor(Garagegate sys) : base(Signal.none, Signal.final)
        {
            system = sys;
            currentState = SensorState.passive;
        }
        protected override void Transition(Signal signal)
        {
            switch (currentState)
            {
                case SensorState.active:
                    switch (signal)
                    {
                        case Signal.activate: break;
                        case Signal.deactivate: currentState = SensorState.passive; break;
                        case Signal.none: Observe(); break;
                        default: throw new UnknownSignalException();
                    }
                    break;
                case SensorState.passive:
                    switch (signal)
                    {
                        case Signal.activate: currentState = SensorState.active; break;
                        case Signal.deactivate:
                        case Signal.none: break;
                        default: throw new UnknownSignalException();
                    }
                    break;
            }
            Thread.Sleep(100);
        }

        private readonly Random rand = new();
        private void Observe()
        {
            if (rand.Next() % 100 < 1)
            {
                system.engine.Send(Signal.blockage);
            }
        }
    }
}
