﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of garage gates

namespace Garagegate
{
    class Garagegate
    {
        public readonly Engine engine;
        public readonly Sensor sensor;
        public readonly Gate gate;
        private readonly Controller controller;

        public Garagegate()
        {
            controller = new Controller(this);
            gate   = new Gate(this, 5);
            sensor = new Sensor(this); 
            engine = new Engine(this);
        }

        public void Process()
        {
            controller.Control();
        }
    }
}
