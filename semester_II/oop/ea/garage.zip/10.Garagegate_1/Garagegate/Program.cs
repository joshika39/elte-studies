﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    controlling garage gate

using System;

namespace Garagegate
{
    class Program
    {
        static void Main( )
        {
            Garagegate gate = new ();
            gate.Process();
        }
    }
}
