﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    signals

using System;

namespace Garagegate
{
    public enum Signal { none, final, up, down, stop, unrolled, coiled, blockage, activate, deactivate };

    public class UnknownSignalException : Exception {}
/*
    class Event
    {
        public Signal signal;

        public Event(Signal s) { signal = s; }

    }
*/
}
