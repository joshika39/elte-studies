﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of controllers

using System;

namespace Garagegate
{
    class Controller
    {
        private readonly Garagegate system;
        public Controller(Garagegate s) { system = s; }
        public void Control()
        {
            MenuWrite();
            int v;
            do
            {
                v = int.Parse(Console.ReadLine());  // ellenőrzés kell még
                switch (v)
                {
                    case 0: system.engine.Send(Signal.final); 
                            system.sensor.Send(Signal.final); break;
                    case 1: system.engine.Send(Signal.up); break;
                    case 2: system.engine.Send(Signal.down); break;
                    case 3: system.engine.Send(Signal.stop); break;
                }
            } while (v != 0);
        }
        private static void MenuWrite()
        {
            Console.WriteLine("Menupoints:");
            Console.WriteLine("0 - exit");
            Console.WriteLine("1 - up");
            Console.WriteLine("2 - down");
            Console.WriteLine("3 - stop");
        }
    }
}
