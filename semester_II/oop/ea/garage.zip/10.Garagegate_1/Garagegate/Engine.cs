﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of engines

using System;
using System.Threading;

namespace Garagegate
{
    class Engine : StateMachine<Signal>
    {
        public  readonly Garagegate system;
        enum EngineState { upward, downward, unmove };
        private EngineState currentState, prevState;
        public string CurrentState
        {
            get { return currentState.ToString(); }
        }
        public Engine(Garagegate sys):base(Signal.none, Signal.final)
        {
            system = sys;
            currentState = EngineState.unmove;
        }
        protected override void Transition(Signal signal)
        {
            //Animáció
            if (!(currentState == EngineState.unmove && prevState == EngineState.unmove))
            {
                string ss = "   state: ";
                if      (currentState == EngineState.unmove)     ss += "gate is unmoving";
                else if (currentState == EngineState.downward)   ss += "gate is descending";
                else if (currentState == EngineState.upward)     ss += "gate is rising"; 
                else if (signal == Signal.final) ss += "gate over"; 
                ss += ", current length: " + system.gate.CurrentLength.ToString()
                    + ", sensor in " + system.sensor.CurrentState.ToString();
                Console.WriteLine(ss);
            }

            prevState = currentState;

            switch (currentState)
            {
                case EngineState.upward:
                    switch (signal)
                    {
                        case Signal.up: system.gate.Up(); break;
                        case Signal.down: currentState = EngineState.downward; break;
                        case Signal.stop:
                        case Signal.blockage:
                        case Signal.coiled:
                        case Signal.unrolled: 
                            system.sensor.Send(Signal.deactivate); 
                            currentState = EngineState.unmove; break;
                        case Signal.none: system.gate.Up(); break;
                        default: throw new UnknownSignalException();
                    }
                    break;
                case EngineState.downward:
                    switch (signal)
                    {
                        case Signal.up: currentState = EngineState.unmove; break;
                        case Signal.down: system.gate.Up(); break;
                        case Signal.stop:
                        case Signal.blockage:
                        case Signal.coiled:
                        case Signal.unrolled:
                            system.sensor.Send(Signal.deactivate);
                            currentState = EngineState.unmove; break;
                        case Signal.none: system.gate.Down(); break;
                        default: throw new UnknownSignalException();
                    }
                    break;
                case EngineState.unmove:
                    switch (signal)
                    {
                        case Signal.up: 
                            system.sensor.Send(Signal.activate);
                            currentState = EngineState.upward; break;
                        case Signal.down:
                            system.sensor.Send(Signal.activate);
                            currentState = EngineState.downward; break;
                        case Signal.stop:
                        case Signal.blockage:
                        case Signal.coiled:
                        case Signal.unrolled:
                        case Signal.none: break;
                        default: throw new UnknownSignalException();
                    }
                    break;
            }

            Thread.Sleep(1000);
        }
    }
}
