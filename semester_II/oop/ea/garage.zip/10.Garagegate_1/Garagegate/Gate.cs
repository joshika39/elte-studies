﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of gates

namespace Garagegate
{
    class Gate
    {
        public  readonly Garagegate system;

        private readonly int maxLength;
        public int CurrentLength { get; private set; }

        public Gate(Garagegate s, int m)
        {
            system = s; 
            maxLength = m;
            CurrentLength = 0; 
        }

        public void Up()
        {
            if (CurrentLength > 0) --CurrentLength;
            if (0 == CurrentLength) system.engine.Send(Signal.coiled);
        }

        public void Down()
        {
            if (CurrentLength < maxLength) ++CurrentLength;
            if (maxLength == CurrentLength) system.engine.Send(Signal.unrolled);
        }
    }
}
