﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of engines

using System;
using System.Threading;

namespace Garagegate
{
    class Engine : StateMachine<Signal>
    {
        public  readonly Garagegate system;
        private EngineState currentState, prevState;
        public string CurrentState
        {
            get { return currentState.ToString(); }
        }
        public Engine(Garagegate sys):base(Signal.none, Signal.final)
        {
            system = sys;
            currentState = Unmove.Instance(this);
        }
        protected override void Transition(Signal signal)
        {
            //Animáció
            if (!(currentState is Unmove && prevState is Unmove))
            {
                string ss = "   state: ";
                if      (currentState is Unmove)     ss += "gate is unmoving";
                else if (currentState is Downward)   ss += "gate is descending";
                else if (currentState is Upward)     ss += "gate is rising"; 
                else if (signal == Signal.final) ss += "gate over"; 
                ss += ", current length: " + system.gate.CurrentLength.ToString()
                    + ", sensor in " + system.sensor.CurrentState.ToString()[6..];
                Console.WriteLine(ss);
            }

            prevState = currentState;
            currentState = currentState.Transition(signal);
            Thread.Sleep(1000);
        }
    }

    abstract class EngineState
    {
        protected Engine engine;
        protected EngineState(Engine e) { engine = e; }
        public virtual EngineState Transition(Signal signal) { return this; }
    }

    class Upward : EngineState
    {
        private static Upward instance = null;
        private Upward(Engine e) : base(e) { }
        public static Upward Instance(Engine s)
        {
            if (instance == null) instance = new Upward(s);
            return instance;
        }
        public override EngineState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.up: 
                    engine.system.gate.Up(); 
                    return this;
                case Signal.down:  
                    return Downward.Instance(engine);
                case Signal.stop:
                case Signal.blockage:
                case Signal.coiled:
                case Signal.unrolled: 
                    engine.system.sensor.Send(Signal.deactivate); 
                    return Unmove.Instance(engine);
                case Signal.none: engine.system.gate.Up(); return this;
                default: throw new UnknownSignalException();
            }
        }
    }

    class Downward : EngineState
    {
        private static Downward instance = null;
        private Downward(Engine e) : base(e) { }
        public static Downward Instance(Engine s)
        {
            if (instance == null) instance = new Downward(s);
            return instance;
        }
        public override EngineState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.up:
                    return Unmove.Instance(engine);
                case Signal.down: 
                    engine.system.gate.Up(); 
                    return this;
                case Signal.stop:
                case Signal.blockage:
                case Signal.coiled:
                case Signal.unrolled:
                    engine.system.sensor.Send(Signal.deactivate);
                    return Unmove.Instance(engine);
                case Signal.none: engine.system.gate.Down(); return this;
                default: throw new UnknownSignalException();
            }
        }
    }

    class Unmove : EngineState
    {
        private static Unmove instance = null;
        private Unmove(Engine e) : base(e) { }
        public static Unmove Instance(Engine s)
        {
            if (instance == null) instance = new Unmove(s);
            return instance;
        }
        public override EngineState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.up:
                    engine.system.sensor.Send(Signal.activate);
                    return Upward.Instance(engine);
                case Signal.down:
                    engine.system.sensor.Send(Signal.activate);
                    return Downward.Instance(engine);
                case Signal.stop:
                case Signal.blockage:
                case Signal.coiled:
                case Signal.unrolled:
                case Signal.none: return this;
                default: throw new UnknownSignalException();
            }
        }
    }
}
