﻿//Author:   Gregorics Tibor
//Date:     2021.11.15.
//Title:    class of sensors

using System;
using System.Threading;

namespace Garagegate
{
    class Sensor : StateMachine<Signal>
    {
        public readonly Garagegate system;
        private SensorState currentState;
        public string CurrentState
        {
            get { return currentState.ToString(); }
        }
        public Sensor(Garagegate sys) : base(Signal.none, Signal.final)
        {
            system = sys;
            currentState = Passive.Instance(this);
        }
        protected override void Transition(Signal signal)
        {
            currentState = currentState.Transition(signal);
            Thread.Sleep(100);
        }
    }

    abstract class SensorState 
    {
        protected Sensor sensor;
        protected SensorState(Sensor s) { sensor = s; }
        public virtual SensorState Transition(Signal signal) { return this; }
    }
    class Active : SensorState
    {
        private static Active instance = null;
        private Active(Sensor s) : base(s) { }

        public static Active Instance(Sensor s)
        {
            if (instance == null) instance = new Active(s);
            return instance; 
        }

        public override SensorState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.activate: return this;
                case Signal.deactivate: return Passive.Instance(sensor); 
                case Signal.none: Observe(); return this;
                default: throw new UnknownSignalException();
            }
        }

        private readonly Random rand = new ();
        private void Observe()
        {
            if (rand.Next() % 100 < 1)
            {
                sensor.system.engine.Send(Signal.blockage);
            }
        }
    }

    class Passive : SensorState
    {
        private static Passive instance = null;
        private Passive(Sensor s) : base(s) { }

        public static Passive Instance(Sensor s)
        {
            if (instance == null) instance = new Passive(s);
            return instance;
        }

        public override SensorState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.activate: return Active.Instance(sensor);
                case Signal.deactivate:
                case Signal.none: return this;
                default: throw new UnknownSignalException();
            }
        }
    }
}
